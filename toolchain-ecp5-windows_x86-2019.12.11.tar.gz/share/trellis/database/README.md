# Project Trellis - Lattice ECP5 Bitstream Documentation

[TOC]

This repo contains the bitstream documentation database for Lattice ECP5
devices.

This documentation was generated using the
[Project Trellis tools](https://github.com/SymbiFlow/prjtrellis).

# License

These files are released under the very permissive [CC0 1.0 Universal](COPYING).

